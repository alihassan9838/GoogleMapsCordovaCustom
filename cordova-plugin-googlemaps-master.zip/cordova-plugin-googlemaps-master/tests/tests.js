exports.defineAutoTests = function () {

  describe('FirebaseCore (plugin.firebase.app)', function () {

    it('plugin.firebase.app should exist', function () {
        expect(plugin.firebase.app).toBeDefined();
    });

  });

};
